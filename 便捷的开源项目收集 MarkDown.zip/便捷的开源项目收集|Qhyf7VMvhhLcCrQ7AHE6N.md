# 便捷的开源项目收集

* **知识管理：AFFINE**

[GitHub - toeverything/AFFiNE: There can be more than Notion and Miro. AFFiNE is a next-gen knowledge base that brings planning, sorting and creating all together. Privacy first, open-source, customizable and ready to use.](https://github.com/toeverything/AFFiNE)

* **Linux 命令大全**

[GitHub - jaywcjlove/linux-command: Linux命令大全搜索工具，内容包含Linux命令手册、详解、学习、搜集。https://git.io/linux](https://github.com/jaywcjlove/linux-command)

* **Java 程序员眼中的 Linux**

[GitHub - judasn/Linux-Tutorial: 《Java 程序员眼中的 Linux》](https://github.com/judasn/Linux-Tutorial)

* **diagrams：用代码绘制云系统架构图**

[GitHub - mingrammer/diagrams: :art: Diagram as Code for prototyping cloud system architectures](https://github.com/mingrammer/diagrams)

* **notepad next：notepad++ 的替代品**

[Bookmark](https://github.com/dail8859/NotepadNext)

* **PhotoPrism：开源的照片管理平台**

[Bookmark](https://github.com/photoprism/photoprism)

* **System-design-101：用图像和简单的术语来解释复杂的系统**

[GitHub - ByteByteGoHq/system-design-101: Explain complex systems using visuals and simple terms. Help you prepare for system design interviews.](https://github.com/ByteByteGoHq/system-design-101)

* **Hoppscotch：现代化的API请求和响应模拟工具**

[Bookmark](https://github.com/hoppscotch/hoppscotch)

* **AJ-Report：大屏可视化拖拽编辑**

[anji-plus/AJ-Report](https://gitee.com/anji-plus/report)

* TOML：清晰简洁的配置文件格式

[Bookmark](https://github.com/toml-lang/toml)

* Xonsh：python 和 shell 的融合

[Bookmark](https://github.com/xonsh/xonsh)

* NetTrace：开源视觉路由工具

[Bookmark](https://github.com/nxtrace)

* Neovim：Linux 下最好用的文本编辑器

[GitHub - neovim/neovim: Vim-fork focused on extensibility and usability](https://github.com/neovim/neovim)

* **LearnGitBranching：**Git 仓库可视化工具、沙盒环境以及一系列交互式教程和挑战的综合工具

[GitHub - pcottle/learnGitBranching: An interactive git visualization and tutorial. Aspiring students of git can use this app to educate and challenge themselves towards mastery of git!](https://github.com/pcottle/learnGitBranching)

* Sourcetrail：代码结构分析

[GitHub - CoatiSoftware/Sourcetrail: Sourcetrail - free and open-source interactive source explorer](https://github.com/CoatiSoftware/Sourcetrail)

**Netcat** 的功能非常广泛，以下是一些它的主要功能：

1. **端口扫描**：您可以使用 **Netcat** 来扫描目标计算机上的网络端口，以确定哪些端口处于打开状态，从而帮助识别潜在的漏洞。

1. **网络监听**：**Netcat** 可以将计算机设置为监听模式，等待来自其他计算机的连接请求。一旦连接建立，**Netcat** 将允许您与远程计算机进行通信。

1. **数据传输**：**Netcat** 可以用于在计算机之间传输数据。它可以将文件内容发送到远程计算机，也可以接收文件并保存到本地计算机。

1. **网络代理**：**Netcat** 可以用于创建网络代理，将一个计算机的流量中继到另一个计算机上。这在绕过防火墙或匿名访问网络时非常有用。

1. **反向连接**：**Netcat** 允许您建立反向连接，这意味着一个计算机可以连接到另一个计算机，而不是等待连接请求。这在穿越网络障碍或在不同网络之间建立连接时非常有用。

1. **广播**：**Netcat** 可以用于向特定网络或广播地址发送数据包。这对于向多个计算机广播消息或数据非常有用。

* Dive：镜像分析

[GitHub - wagoodman/dive: A tool for exploring each layer in a docker image](https://github.com/wagoodman/dive)

* **screenshot-to-code：截屏变代码**

[Bookmark](https://github.com/abi/screenshot-to-code)

* **GPT Crawler：自动爬虫打造私有GPT**

[GitHub - BuilderIO/gpt-crawler: Crawl a site to generate knowledge files to create your own custom GPT from a URL](https://github.com/BuilderIO/gpt-crawler)

* GitHubDaily 的开源项目列表

[GitHub - GitHubDaily/GitHubDaily: 坚持分享 GitHub 上高质量、有趣实用的开源技术教程、开发者工具、编程网站、技术资讯。A list cool, interesting projects of GitHub.](https://github.com/GitHubDaily/GitHubDaily)

其余：

[PDFgear - 将易于使用的PDF软件带给大众](https://www.pdfgear.com/zh/)

[ChartCube - 在线图表制作工具](https://chartcube.alipay.com/guide/)

[Bookmark](https://github.com/antvis)

[Bookmark](https://github.com/diegocr/netcat)

[Bookmark](https://codegeex.cn/)

[Applite: 一款优秀的 Homebrew 图形管理工具](https://mp.weixin.qq.com/s/zWi2uJ36F17MsW1kCrbSng)

[最全vue3开源管理系统汇总](https://mp.weixin.qq.com/s/NoIl3KI02RbwJMhRV9jl1A)

[10款变态提效神器，打工人必备！](https://mp.weixin.qq.com/s/CCxL-Wj9at5fH5U0AEG2DA)